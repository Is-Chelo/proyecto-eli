const { Op } = require('sequelize');
const { Sequelize } = require('../models');

class Filter {
    static async applyFilter(query, ModelName) {
        try {
            const filters = query;
            let queryWithFilter = [];

            for (const key in filters) {
                let value = filters[key];

                if (value === 'true') value = true;
                else if (value === 'false') value = false;

                if (key === 'fecha_registro_inicio' || key === 'fecha_registro_fin') {
                    // Filtrar por rango de fechas de registro
                    const startDate = new Date(filters['fecha_registro_inicio']);
                    const endDate = new Date(filters['fecha_registro_fin']);
                    queryWithFilter.push({
                        fecha_registro: {
                            [Op.between]: [startDate, endDate]
                        }
                    });
                } else {
                    if (value === true || value === false) {
                        queryWithFilter.push({
                            [key]: value
                        });
                    } else {
                        queryWithFilter.push({
                            [key]: {
                                [Op.like]: `%${value}%`
                            }
                        });
                    }
                }
            }

            const result = await ModelName.findAll({
                where: {
                    [Op.and]: queryWithFilter,
                },
            });

            return result;
        } catch (error) {
            console.error('Error en el filtro:', error);
            return [];
        }
    }
}

module.exports = Filter;
